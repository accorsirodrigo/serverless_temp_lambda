module.exports = {
    SMARTHOME_DATA: "smarthome_data"
}